import { Link } from "react-router-dom";

const NotFound = () => {
    return (
        <div>
            <Link to="/">Home</Link>
            404 Not Found
        </div>
    );
}

export default NotFound;
