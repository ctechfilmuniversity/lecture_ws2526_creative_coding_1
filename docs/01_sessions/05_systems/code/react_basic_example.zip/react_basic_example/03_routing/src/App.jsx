import { Outlet } from "react-router-dom";

import './App.css'

import About from './components/About';
import Contact from './components/Contact';
import Home from './components/Home';
import Navigation from "./components/Navigation.jsx";
import Projects from './components/Projects';

const App = () => {
    return (
        <>
            <Navigation />
            <Outlet /> {/* Renders child routes here */}
        </>
    );
};

export default App
