
const Projects = () => {
    return (
        <>
            <h1>Projects</h1>
            <p>Projects Text</p>
        </>
    );
}

export default Projects;