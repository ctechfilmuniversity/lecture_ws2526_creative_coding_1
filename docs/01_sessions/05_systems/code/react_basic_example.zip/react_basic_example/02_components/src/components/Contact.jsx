const Contact = () => {
    return (
        <>
            <h1>Contact</h1>
            <p>Contact Text</p>
        </>
    );
}

export default Contact;