const About = () => {
    return (
        <>
            <h1>About</h1>
            <p>About Text</p>
        </>
    );
}

export default About;