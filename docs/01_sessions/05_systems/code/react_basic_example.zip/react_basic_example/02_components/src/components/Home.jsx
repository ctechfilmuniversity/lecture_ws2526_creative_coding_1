const Home = () => {
    return (
        <>
            <h1>Home</h1>
            <p>Home Text</p>
        </>
    );
}

export default Home;