import './App.css'
import Scene from './Scene'

function App() {

  return (
    <>
      <Scene />
    </>
  )
}

export default App;
