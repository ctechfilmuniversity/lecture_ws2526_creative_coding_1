import { Canvas } from "@react-three/fiber";
import { OrbitControls, Text } from "@react-three/drei";

function Scene() {
  return (
    <Canvas style={{ width: "100vw", height: "100vh" }}>
      <OrbitControls />
      <Text position={[0, 0, 0]} fontSize={0.7}>
        Hello RTF & Drei 👋🏻
      </Text>
    </Canvas>
  );
}
export default Scene;